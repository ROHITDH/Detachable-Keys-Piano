Open piano.asc in LTSpice or drag and drop it on LTSpice
Connect VCC to required keys -- Basically, when we press the key, it connects to VCC and produce the sounds
Keys are mountable
Click run , output wav file will be created in same directory, play it to listen sound

Its the software version of hardware implementation.